#include "course.h"

// Constructor definition
Course::Course(int code, int marks) : courseCode(code), marks(marks) { }
